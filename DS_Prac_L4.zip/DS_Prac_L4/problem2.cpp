/**
 * @file problem2.cpp
 * @author Ritesh Singh (you@domain.com)
 * @brief This program solve N Queen problem
 * @version 0.1
 * @date 2019-09-04
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#include<iostream>
using namespace std; 
#include<bits/stdc++.h>

int c=1;

void Display_Board(int **a,int N) ;
bool check_Quuen_pos(int **a, int row, int col,int N);
bool solve_NQueen(int **a, int col,int N) ;
void make_board(int N);


/**
 * @brief This is the main fuction
 * 
 * @return int Default return
 */
int main() 
{ 
	int N;
	cout<<"Enter the size of the Board"<<endl;
	cin>>N;
	cout<<"The size of Board is: "<<N<<endl;
	make_board(N); 
	return 0; 
} 

/**
 * @brief A utility function to print solution 
 * 
 * @param a An array
 * @param N It is the size of array
 */

void Display_Board(int **a,int N) 
{ 
	cout<<c<<":"<<endl;
	for (int i = 0; i < N; i++) 
	{ 
		for (int j = 0; j < N; j++)
		{ 
			printf(" %d ", a[i][j]);
		} 
		printf("\n"); 
	} 
	printf("\n");
	c++;

} 

/**
 * @brief It is function to check if a queen can 
be placed on board[row][col].
 * 
 * @param a An array
 * @param row the row
 * @param col the column
 * @param N the size of board
 * @return true returns true
 * @return false returns false
 */


bool check_Quuen_pos(int **a, int row, int col,int N) 
{ 
	
	for (int i = 0; i < col; i++) 
		if (a[row][i]) 
			return false; 

	for (int i=row, j=col; i>=0 && j>=0; i--, j--) 
		if (a[i][j]) 
			return false; 

	for (int i=row, j=col; j>=0 && i<N; i++, j--) 
		if (a[i][j]) 
			return false; 

	return true; 
} 


/**
 * @brief function to solve N Queen problem 
 * 
 * @param a an array
 * @param col the column
 * @param N size of the board
 * @return true return true
 * @return false return false
 */

bool solve_NQueen(int **a, int col,int N) 
{ 
	/* base case: If all queens are placed 
	then return true */
	if (col == N) 
	{ 
		Display_Board(a,N); 
		return true; 	
	} 

	bool res = false; 
	for (int i = 0; i < N; i++) 
	{ 
		
		if ( check_Quuen_pos(a, i, col,N) ) 
		{ 
		
			a[i][col] = 1; 

			
			res = solve_NQueen(a, col + 1,N) || res; 

			a[i][col] = 0; 
		} 
	} 

	return res; 
} 

/**
 * @brief  function solves the N Queen problem using 
Backtracking.
 * 
 * @param N size of board
 */

void make_board(int N) 
{ 
	int **a;
	a=new int*[N];
	for(int i=0;i<N;i++)
	a[i]=new int[N];
    
	for(int i=0;i<N;i++)
	for(int j=0;j<N;j++)
	a[i][j]=0;
    
	if (solve_NQueen(a, 0,N) == false) 
	{ 
		cout<<"No Solution is Possible"<<endl; 
		return ; 
	} 

} 