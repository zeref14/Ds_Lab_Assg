/**
 * @file problem3.cpp
 * @author Ritesh Singh (you@domain.com)
 * @brief the program solves the sub-array problem
 * @version 0.1
 * @date 2019-09-04
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#include<iostream>
#include <bits/stdc++.h>
using namespace std;


void find_subarray(int *a,int n,int k,unordered_map<int,int>&index);
void display_subarray(int n,unordered_map<int,int>&index);

/**
 * @brief the driver function
 * 
 * @return int default return
 */
int main()
{
    int n,k;
    cout<<"Enter the length of Sub-Array:"<<endl;
    cin>>n;
    cout<<"Enter the required Sum:"<<endl;
    cin>>k;
    int *a;
    a=new int[n];
    cout<<"Enter the Data for Sub-Array"<<endl;
    for(int i=0;i<n;i++)
    cin>>a[i];
    
    unordered_map<int,int>index;

    find_subarray(a,n,k,index);
    
    return 0;
}

/**
 * @brief this function finds subarray whose sum is k
 * 
 * @param a the array
 * @param n the size of array
 * @param k the sum
 * @param index an unordered map
 */
void find_subarray(int *a,int n,int k,unordered_map<int,int>&index)
{
    int count_sum=0;
    for(int i=0;i<n;i++)
    {
        for(int j=i;j<n;j++)
        {
            count_sum=count_sum+a[j];
            if(count_sum==k)
            {
                index[i]=j-i+1;//stores ;ength of subarray for which sum=k
            }

        }
        count_sum=0;
    }

    display_subarray(n,index);
}
/**
 * @brief this function displays the output
 * 
 * @param n the size of board
 * @param index the unordered map which contains index
 */
void display_subarray(int n,unordered_map<int,int>&index)
{
    int a=0,k, j;
    for(int i=0;i<n;i++)
    {
        a=(a>index[i])?a:index[i];//find the max index value
        if(a==index[i])
        k=i;
    }
    if(a==0)
    {
        cout<<"No Sub-Array Possible"<<endl;
    }
    else
    {
        j=a+k-1;
        cout<<"Range of Index of Sub-Array is: "<<k<<"-"<<j<<endl;
        cout<<"The length of longest Sub-Array is: "<<a<<endl;
    }
    
}