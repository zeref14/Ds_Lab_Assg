var searchData=
[
  ['main',['main',['../problem2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem2.cpp'],['../problem3_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem3.cpp']]],
  ['make_5fboard',['make_board',['../problem2_8cpp.html#a67f0758bb352554fffc162d087e3ca60',1,'problem2.cpp']]]
];
