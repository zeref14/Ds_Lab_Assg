var searchData=
[
  ['c',['c',['../problem2_8cpp.html#a4e1e0e72dd773439e333c84dd762a9c3',1,'problem2.cpp']]],
  ['check_5fquuen_5fpos',['check_Quuen_pos',['../problem2_8cpp.html#aac8beebff2303b53b3fbd6bd6c189ac2',1,'problem2.cpp']]]
];
