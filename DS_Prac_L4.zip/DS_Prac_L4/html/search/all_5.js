var searchData=
[
  ['solve_5fnqueen',['solve_NQueen',['../problem2_8cpp.html#a9598ca50f45172ab76a52ea40b932b5a',1,'problem2.cpp']]]
];
